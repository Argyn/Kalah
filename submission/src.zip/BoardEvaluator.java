package MKAgent;

public interface BoardEvaluator {

  double evaluateBoard(Board board, Side side);

}
